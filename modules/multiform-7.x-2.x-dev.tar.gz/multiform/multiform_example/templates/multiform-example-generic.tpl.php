<p>
<?php
print t('You can define your own templates for multiforms. <br />See multiform settings and multifrom_example_theme() for details.');
?>
</p>


<?php
print drupal_render_children($form);
